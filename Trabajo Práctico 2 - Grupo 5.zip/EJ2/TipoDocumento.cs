﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EJ2
{
    enum TipoDocumento
    {
        DNI,
        CUIT,
        CUIL,
        LE,
        LC
    }
}
