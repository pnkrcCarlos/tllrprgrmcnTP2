using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EJ4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("TP2/EJ4");
            Console.ReadKey();
        }
    }
}
